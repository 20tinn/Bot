const toinmenu = (prefix, pushname) => {
    return `◪ *Comandos do Toin*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.toinmenu = toinmenu