const help = (prefix) => {
	return `
<══════════════════════>
      *BOT DO CAUSS*
v:1.0  <══════════════════════>



😐 *info do bot*
  🐉 Prefix: >  *  <
  🐉 Dono: CAUSS  
  🐉 Canal do criador: https://youtube.com/channel/UCpB3qh2Sp3K23s9a2Q-Gf-g
  🐉 *Parcerias*: *parceria
😐 *SOBRE*
  │
  ├─ 🐉 ${prefix}info
  ├─ 🐉 ${prefix}blocklist
  ├─ 🐉 ${prefix}chatlist
  ├─ 🐉 ${prefix}ping
  ├─ 🐉 ${prefix}dono
  ├─ 🐉 ${prefix}appbot
  └─ 🐉 ${prefix}bugreport 
😐 *favoritos*
  │
  ├─ 🐉 ${prefix}sticker
  ├─ 🐉 ${prefix}play 
  ├─ 🐉 ${prefix}stickergif
  ├─ 🐉 ${prefix}toimg
  ├─ 🐉 *tomp3
  ├─ 🐉 *marvellogo 
  ├─ 🐉 *3dtext
  ├─ 🐉 *phlogo
  ├─ 🐉 *glitch
  ├─ 🐉 *neonlogo
  ├─ 🐉 *lionlogo
  ├─ 🐉 *jokerlogo
  ├─ 🐉 *coffee
  ├─ 🐉 *lovepaper
  
😐 *MEDIA*
  │
  ├─ 🐉 *trendtwit
  ├─ 🐉 *randomkpop
  └─ 🐉 *ytsearch
😐 *uiui, nada de colar*
  │
  ├─ 🐉 *wiki
  ├─ 🐉 *wikien
  ├─ 🐉 *nulis
  └─ 🐉 *Google

😐 *DOWNLOADER*
  │
  ├─ 🐉 *images
  ├─ 🐉 *ytmp3
  ├─ 🐉 *ytmp4
  ├─ 🐉 *tiktok
  └─ 🐉 *joox
😐 *MEME*
  │
  ├─ 🐉 *meme
  └─ 🐉 *memeindo
😐 *SOM*
  │
  ├─ 🐉 *play
  └─ 🐉 *tts
😐 *MÚSICA*
  │
  ├─ 🐉 *lirik
  └─ 🐉 *chord
😐 *ISLAM*
  │
  └─ 🐉 *quran
😐 *STALK*
  │
  ├─ 🐊 *tiktokstalk
  └─ 🐊 *igstalk
😐 *WIBU*
  │
  ├─ 🐉 *neonime
  ├─ 🐉 *pokemon
  ├─ 🐉 *loli
  ├─ 🐉 *waifu
  ├─ 🐉 *randomanime
  ├─ 🐉 *husbu
  ├─ 🐉 *husbu2
  ├─ 🐉 *wait
  └─ 🐉 *nekonime
😐 *DIVERSÃO*
  │
  ├─ 🐉 *alay
  ├─ 🐉 *gantengcek
  ├─ 🐉 *watak
  ├─ 🐉 *hobby
  ├─ 🐉 *game
  ├─ 🐉 *bucin
  ├─ 🐉 *trust
  ├─ 🐉 *dare
  └─ 🐉 *simi
😐 *INFORMAÇÃO*
  │
  ├─ 🐉 *bahasa
  └─ 🐉 *covid
😐 *COMANDOS DO CAUSS*
  │
  ├─ 🐉 *setprefix
  ├─ 🐉 *block
  ├─ 🐉 *bc
  ├─ 🐉 *bcgc
  ├─ 🐉 *clone
  └─ 🐉 *clearall
😐 *aleatório*
  │
  ├─ 🐉 *send
  ├─ 🐉 *wame
  ├─ 🐉 *virtex
  ├─ 🐉 *exe
  ├─ 🐉 *qrcode
  ├─ 🐉 *afk
  ├─ 🐉 *timer
  ├─ 🐉 *fml
  └─ 🐉 *fml2

   ( *CASO O BOT NÃO RESPONDA MANDE O COMANDO NOVAMENTE, NADA DE FLOOD* )
`
}

exports.help = help
