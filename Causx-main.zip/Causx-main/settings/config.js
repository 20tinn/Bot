const config = {
        botName: 'CAUSS_BOT',
        ownerName: 'CAUSS',
        youtube: 'https://youtube.com/channel/UCpB3qh2Sp3K23s9a2Q-Gf-g',
        instagram: 'https://instagram.com/animexx_png?igshid=e7zziiwn3d9y',
}
